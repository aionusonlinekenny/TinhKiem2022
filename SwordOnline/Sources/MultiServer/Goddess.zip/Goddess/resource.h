//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Goddess.rc
//
#define IDD_DLG_GODDESS                 101
#define IDI_GODDESS                     102
#define IDC_EDIT_PORT                   1000
#define IDC_LIST_CLIENT                 1001
#define IDC_STATIC_SERVICE              1002
#define IDC_STATIC_DATABASE             1003
#define IDC_EDIT_MAXNUM_ROLE            1004
#define IDC_EDIT_BACKUP_SLEEP_TIME      1005
#define IDC_EDIT_BACKUP_SPACE_TIME      1006
#define IDC_EDIT_BACKUP_BEGIN_TIME      1007
#define IDC_BTN_BACKUP_SUS_RES          1008
#define IDC_LAB_BACKUP_STATUS           1009
#define IDC_BTN_BACKUP_MANUAL           1010
#define IDC_BUTTON1                     1011
#define IDC_RESTART                     1012
#define IDC_OUTPUT                      1013
// >>> ADD:
#define IDC_CHK_AUTO_BACKUP             1014
#define IDC_EDIT_AUTO_MINUTES           1015
#define IDC_STATIC_AUTO_MINUTES         1016
// <<< ADD
// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1017
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
